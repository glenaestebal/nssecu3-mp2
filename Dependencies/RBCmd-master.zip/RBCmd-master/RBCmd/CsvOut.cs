﻿namespace RBCmd;

public class CsvOut
{
    public string SourceName { get; set; }
    public string FileType { get; set; }
    public string FileName { get; set; }
    public long FileSize { get; set; }
    public string DeletedOn { get; set; }
}